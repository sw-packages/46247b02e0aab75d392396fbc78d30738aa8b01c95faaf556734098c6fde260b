#ifndef WEBCC_VERSION_H_
#define WEBCC_VERSION_H_

#define WEBCC_VERSION "0.1.0"

#endif  // WEBCC_VERSION_H_
